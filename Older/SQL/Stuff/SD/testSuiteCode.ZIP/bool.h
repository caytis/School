#ifndef BOOL_H
#define BOOL_H

typedef int bool;
enum {FALSE, TRUE};
#endif
