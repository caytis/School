nums = (i*i for i in range(5))
for x in nums: print x
for x in nums: print x

''' Output
0
1
4
9
16
'''
