# first.py
name = raw_input("Enter your first name: ")
age = input("Enter your age (we won't tell!): ")
print "So,", name, "you're",age
print type(name)
print type(age)

